<?php
/**
 * Plugin Name: OpenPlus Asesores - Menu movil
 * Description: Ajuste visual y de accesibilidad del menu movil corporativo.
 * Version: 1.0.0
 * Author: OpenPlus Asesores
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) {
    exit;
}
add_action('wp_enqueue_scripts', function () {
    if (is_admin()) {
        return;
    }
    $base = plugin_dir_url(__FILE__);
    wp_enqueue_style(
        'openplus-menu-movil',
        $base . 'assets/mobile-menu.css',
        array(),
        '1.0.0'
    );
    wp_enqueue_script(
        'openplus-menu-movil',
        $base . 'assets/mobile-menu.js',
        array(),
        '1.0.0',
        true
    );
}, 99);
