(function () {
  'use strict';
  function ready() {
    var root = document.querySelector('.menu-mobile');
    if (!root) return;
    var toggle = root.querySelector('.m-burger');
    var panel = root.querySelector('.m-panel');
    if (!toggle || !panel) return;
    if (!panel.querySelector('.op-mm-footer')) {
      var footer = document.createElement('div');
      footer.className = 'op-mm-footer';
      var cta = document.createElement('a');
      cta.className = 'op-mm-cta';
      cta.href = 'https://openplusasesores.es/haz-tu-consulta/';
      cta.textContent = 'Solicitar presupuesto';
      footer.appendChild(cta);
      panel.appendChild(footer);
    }
    var media = window.matchMedia('(max-width: 980px)');
    function sync() {
      var open = media.matches && toggle.getAttribute('aria-expanded') === 'true';
      document.documentElement.classList.toggle('op-mm-open', open);
      document.body.classList.toggle('op-mm-open', open);
    }
    var observer = new MutationObserver(sync);
    observer.observe(toggle, { attributes: true, attributeFilter: ['aria-expanded'] });
    toggle.addEventListener('click', function () {
      window.requestAnimationFrame(sync);
    });
    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape' || !document.body.classList.contains('op-mm-open')) return;
      if (toggle.getAttribute('aria-expanded') === 'true') {
        toggle.click();
        toggle.focus();
      }
    });
    window.addEventListener('resize', sync, { passive: true });
    panel.addEventListener('click', function (event) {
      var target = event.target;
      var link = target && target.closest ? target.closest('a') : null;
      if (!link || !link.href) return;
      if (link.hash && link.pathname === window.location.pathname &&
          toggle.getAttribute('aria-expanded') === 'true') {
        toggle.click();
      }
    });
    sync();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ready, { once: true });
  } else {
    ready();
  }
}());
